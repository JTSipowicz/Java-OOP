package AccountManager.controller;
import AccountManager.model.Account;
import java.math.BigDecimal;
import AccountManager.model.OverdrawnException;
import AccountManager.view.AccountView;
import javax.swing.SwingUtilities;
public class AccountController extends AbstractController {
	public void operation(String opt) {
		if(opt == AccountView.Deposit) {
			BigDecimal amount = ((AccountView)getView()).getAmount();
			((Account)getModel()).deposit(amount);
		} else if(opt == AccountView.Withdraw) {
			BigDecimal amount = ((AccountView)getView()).getAmount();
			try {
				((Account)getModel()).withdraw(amount);
			}
			catch(OverdrawnException ex) {
				final String msg = ex.getMessage();
				SwingUtilities.invokeLater(new Runnable() {
				      public void run() {
				    	  ((AccountView)getView()).showError(msg);
				      }
				});
			}
		}
	}
}
