package AccountManager.controller;

import AccountManager.model.AccountList;
import AccountManager.model.Account;
import AccountManager.view.AccountListView;
import AccountManager.view.AccountView;

import java.io.File;
import java.util.ArrayList;

public class AccountListController extends AbstractController{
/**
 * Seperates string read with commas, places them into a result file
 * @param file
 * @return
 */
    public static ArrayList createAcctList(File file) {
        ArrayList<Account> accounts = AccountList.start(file);
        return accounts;
    }
    public void buttonOperation(String opt, int index){
        ArrayList<Account> accounts = AccountList.getAccountList();
        ArrayList<Account> accountsEuro = AccountList.accountsEuro();
        ArrayList<Account> accountsYen = AccountList.accountsYen();
        if(opt == AccountView.Save) {
            AccountList.end( );
        } else if(opt == AccountListView.SaveAndExit) {
            AccountList.end( );
            AccountListView acView = (AccountListView) getView();
            acView.dispose();
        } else if (opt == AccountListView.EditInDollars) {
            accounts.get(index).setCurrencyType("Dollars");
            AccountView.accountView(accounts.get(index));
        }else if (opt == AccountListView.EditInEuros) {
            accountsEuro.get(index).setCurrencyType("Euros");
            AccountView.accountView(accountsEuro.get(index));
        }else if (opt == AccountListView.EditInYen) {
            accountsYen.get(index).setCurrencyType("Yen");
            AccountView.accountView(accountsYen.get(index));
        }
    }
}