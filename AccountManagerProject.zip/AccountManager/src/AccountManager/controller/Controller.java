package AccountManager.controller;
import AccountManager.view.View;
import AccountManager.model.Model;
public interface Controller {
	void setModel(Model model);
	Model getModel();
	View getView();
	void setView(View view);
}
