package AccountManager.view;
import AccountManager.controller.Controller;
import AccountManager.model.Model;
public interface View {
	Controller getController();
	public void setController(Controller aController);
	public Model getModel();
	public void setModel(Model aModel);
}
