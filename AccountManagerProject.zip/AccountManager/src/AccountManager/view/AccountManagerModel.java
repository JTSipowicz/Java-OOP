package AccountManager.view;
public class AccountManagerModel {
}
