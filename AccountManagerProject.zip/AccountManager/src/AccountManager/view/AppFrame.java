package AccountManager.view;

import AccountManager.model.Model;
import AccountManager.model.ModelEvent;
import AccountManager.controller.Controller;
public class AppFrame extends JFrameView {
    private JFramePanel basePanel;

    public AppFrame(Model model, Controller controller) {
        super(model, controller);
    }
    @Override
    public void modelChanged(ModelEvent me) {
    }
}
