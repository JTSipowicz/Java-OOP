package AccountManager.view;
import javax.swing.JFrame;

import AccountManager.model.AbstractModel;
import AccountManager.model.Model;
import AccountManager.model.ModelListener;
import AccountManager.controller.Controller;
public abstract class JFrameView extends JFrame implements View, ModelListener {
	private Model model;
	private Controller controller;
	/**
	 * JFrameView Constructor
	 * @param Model - Model for view
	 * @param Controller - Controller for view
	 */
	public JFrameView (Model model, Controller controller){
		setModel(model);
		setController(controller);
	}
	/**
	 * Registers view with model
	 */
	public void registerWithModel(){
		((AbstractModel)model).addModelListener(this);
	}
	public void unregisterWithModel(){
		((AbstractModel)model).removeModelListener(this);
	}
	/**
	 * Getter for the view's controller
	 */
	public Controller getController(){return controller;}
	
	/**
	 * Setter for view's controller
	 */
	public void setController(Controller controller){
		this.controller = controller;
	}
	/**
	 * Getter for view's model
	 */
	public Model getModel(){return model;}
	
	/**
	 * Setter for view's model
	 */
	public void setModel(Model model) {
		this.model = model;
		registerWithModel();
	}

}
