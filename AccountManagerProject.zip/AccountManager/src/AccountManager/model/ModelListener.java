package AccountManager.model;
public interface ModelListener {
	public void modelChanged(ModelEvent me);
}
