package AccountManager.model;
public enum AgentStatus {
	Running, Blocked, Paused, Pending, NA
}
