package AccountManager.model;

import java.math.BigDecimal;

public class ModelEvent {
	public enum EventKind {
		BalanceUpdate, AgentStatusUpdate, AmountTransferredUpdate
	}
	private EventKind kind;
	private double balance;
	private AgentStatus agSt;
	public ModelEvent(EventKind kind, double balance, AgentStatus agSt){
		this.balance = balance;
		this.kind = kind;
		this.agSt = agSt;
	}
	public ModelEvent(EventKind balanceupdate, BigDecimal balance2, AgentStatus na) {
		// TODO Auto-generated constructor stub
	}
	public EventKind getKind(){return kind;}
	public double getBalance(){
		return balance;
	}
	public AgentStatus getAgStatus(){return agSt;}
}
