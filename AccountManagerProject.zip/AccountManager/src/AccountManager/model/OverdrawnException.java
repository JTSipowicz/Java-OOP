package AccountManager.model;
import java.math.BigDecimal;
public class OverdrawnException extends Exception {
	OverdrawnException(BigDecimal amt) {
		super("Overdrawn by: " + amt);
	}

}

