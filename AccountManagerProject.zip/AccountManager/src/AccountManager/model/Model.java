package AccountManager.model;
public interface Model {
	public void notifyChanged(ModelEvent me);
}
