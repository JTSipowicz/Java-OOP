package AccountManager.test;

import AccountManager.model.Account;
import AccountManager.model.OverdrawnException;

import static org.junit.Assert.*;
import java.math.BigDecimal;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class AccountTest {
	Account accountW;
	@Before
	public void setUp() throws Exception {
		accountW = new Account("Harrison", "76413", new BigDecimal("89.00"),"Dollars", false );
	}

	@After
	public void tearDown() throws Exception {
		accountW = null;
	}
	
	@Test
	public void testWithdraw() throws Exception {
		accountW.withdraw(new BigDecimal("123.56"));
		System.out.println("withdraw, new balance = " + accountW.getBalance());
		assertEquals(accountW.getBalance().toString(), "63.45");
	}
	
	@Test
	public void testDeposit() throws Exception {
		accountW.deposit(new BigDecimal("200.90"));
		System.out.println("deposit, new balance = " + accountW.getBalance());
		assertEquals(accountW.getBalance().toString(), "421.34");
	}
	@Test
	public void testOverdrawException(){
		try{
			accountW.withdraw(new BigDecimal("2900.00"));
			fail("Overdraw exception should be thrown");
		}
		catch(OverdrawnException ex) {
			System.out.println(ex.getMessage());
			assertEquals(ex.getMessage(), "Overdraw by a lot lol");
			assertTrue(true);
		}
	}
}