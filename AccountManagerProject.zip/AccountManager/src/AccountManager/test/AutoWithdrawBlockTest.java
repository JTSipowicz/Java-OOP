package AccountManager.test;

import static org.junit.Assert.*;
import AccountManager.model.Account;
import AccountManager.model.OverdrawnException;
import java.math.BigDecimal;
import AccountManager.model.WithdrawAgent;
import junit.framework.AssertionFailedError;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
public class AutoWithdrawBlockTest {
	Account acc;
	WithdrawAgent withdrawAg;
	final static int TIMEOUT = 500;
	private volatile boolean success = true;
	private class Taker implements Runnable {
		private Account acc;
		public  Taker(Account acc) {this.acc = acc;}
		public void run() {
			try {
				acc.autoWithdraw(new BigDecimal("89.42"), withdrawAg);
				System.out.println("Inside Taker has failed");
				success = false;
				fail("Get Blocker has failed");
			} catch(InterruptedException success){
				System.out.println("Thread Interuption");
			}
			catch(AssertionFailedError ex) {
				System.out.println("AssertionFailedError");
			}
		}
	}
	@Before
	public void setUp() throws Exception {
		acc = new Account("Carl", "99087", new BigDecimal("10.42"), "Dollars", false);
		withdrawAg = new WithdrawAgent(acc, new BigDecimal("10444.00"), 1);
	}
	@After
	public void tearDown() throws Exception {	
	}
	@Test
	public void testWithdrawBlock() {
		Thread taker = new Thread(new Taker(acc));
		try {
			taker.start();
			Thread.sleep(TIMEOUT);
			taker.interrupt();
			taker.join(TIMEOUT);	
			if(success) assertFalse(taker.isAlive());
			else fail();			
		}catch(Exception unexpected){
			fail("unexpected fail");
		}
	}
}