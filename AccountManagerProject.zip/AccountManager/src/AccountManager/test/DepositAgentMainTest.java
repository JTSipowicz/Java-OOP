package AccountManager.test;

import AccountManager.model.Account;
import AccountManager.model.DepositAgent;
import java.math.BigDecimal;

public class DepositAgentMainTest {

	public static void main(String[] args) {
		Account acc = new Account("Prim", "22192", new BigDecimal("99.80"), "Dollars", false);
		DepositAgent depAg = new DepositAgent(acc, new BigDecimal("23.42"), 15);
		depAg.run();
		System.err.println("Balance " + acc.getBalance());

	}

}
